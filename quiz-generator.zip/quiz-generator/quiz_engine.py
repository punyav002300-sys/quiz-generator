"""
quiz_engine.py
==============
Core logic for the AI-Powered Quiz Generator:

1. Document loading & chunking      (PDF / DOCX / TXT)
2. Embedding + FAISS vector store   (LangChain + Ollama embeddings)
3. Retrieval-augmented MCQ generation using an Ollama LLM

This module is intentionally framework-light so it can be unit tested
independently of Flask.
"""

import os
import re
import json
from typing import List, Dict, Any

from langchain_community.document_loaders import (
    PyPDFLoader,
    TextLoader,
    Docx2txtLoader,
)
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import OllamaEmbeddings
from langchain_community.chat_models import ChatOllama
from langchain.prompts import PromptTemplate

# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "llama3")
OLLAMA_BASE_URL = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")

CHUNK_SIZE = 1000
CHUNK_OVERLAP = 150

SUPPORTED_EXTENSIONS = {".pdf", ".txt", ".docx"}

_LOADERS = {
    ".pdf": PyPDFLoader,
    ".txt": TextLoader,
    ".docx": Docx2txtLoader,
}


# --------------------------------------------------------------------------
# Step 1: Document loading & chunking
# --------------------------------------------------------------------------
def load_document(file_path: str):
    ext = os.path.splitext(file_path)[1].lower()
    if ext not in _LOADERS:
        raise ValueError(f"Unsupported file extension: {ext}")
    loader = _LOADERS[ext](file_path)
    return loader.load()


def chunk_documents(documents) -> List[str]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    chunks = splitter.split_documents(documents)
    return chunks


# --------------------------------------------------------------------------
# Step 2: Embedding + FAISS vector store
# --------------------------------------------------------------------------
def get_embeddings():
    return OllamaEmbeddings(model=OLLAMA_MODEL, base_url=OLLAMA_BASE_URL)


def process_document(file_path: str, store_path: str) -> int:
    """
    Load a document, chunk it, embed the chunks, and persist a FAISS
    vector store to disk. Returns the number of chunks indexed.
    """
    documents = load_document(file_path)
    if not documents:
        raise ValueError("No readable text found in the uploaded document.")

    chunks = chunk_documents(documents)
    if not chunks:
        raise ValueError("Document could not be split into any text chunks.")

    embeddings = get_embeddings()
    vectorstore = FAISS.from_documents(chunks, embeddings)
    vectorstore.save_local(store_path)
    return len(chunks)


def load_vectorstore(store_path: str) -> FAISS:
    embeddings = get_embeddings()
    return FAISS.load_local(
        store_path, embeddings, allow_dangerous_deserialization=True
    )


# --------------------------------------------------------------------------
# Step 3: MCQ generation
# --------------------------------------------------------------------------
_MCQ_PROMPT = PromptTemplate(
    input_variables=["context", "num_questions", "difficulty", "topic_hint"],
    template="""
You are an expert exam-question writer creating a candidate assessment.

Using ONLY the CONTEXT below, write {num_questions} multiple-choice questions (MCQs)
at {difficulty} difficulty level.{topic_hint}

Rules:
- Each question must be answerable strictly from the CONTEXT.
- Each question has exactly 4 options labeled A, B, C, D.
- Exactly one option is correct.
- Distractors (wrong options) must be plausible, not silly or obviously wrong.
- Do not repeat the same question twice.
- Do not include explanations, only the quiz content.

Return ONLY valid JSON (no markdown fences, no commentary) matching this schema:
{{
  "questions": [
    {{
      "question": "string",
      "options": {{"A": "string", "B": "string", "C": "string", "D": "string"}},
      "correct_answer": "A" | "B" | "C" | "D"
    }}
  ]
}}

CONTEXT:
{context}
""",
)


def _get_llm(temperature: float = 0.4) -> ChatOllama:
    return ChatOllama(model=OLLAMA_MODEL, base_url=OLLAMA_BASE_URL, temperature=temperature)


def _extract_json(raw_text: str) -> Dict[str, Any]:
    """LLMs sometimes wrap JSON in prose or code fences; extract the JSON object."""
    text = raw_text.strip()
    text = re.sub(r"^```(json)?", "", text.strip())
    text = re.sub(r"```$", "", text.strip())
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if not match:
        raise ValueError("Model response did not contain valid JSON.")
    return json.loads(match.group(0))


def _gather_context(vectorstore: FAISS, topic_hint: str, k: int = 8) -> str:
    """
    Pull a representative sample of chunks from the vector store to use as
    context for question generation. If a topic hint is provided, retrieve
    chunks most relevant to that topic; otherwise sample broadly across the
    document.
    """
    if topic_hint:
        docs = vectorstore.similarity_search(topic_hint, k=k)
    else:
        # Broad sample: pull from the underlying docstore directly so we are
        # not biased toward a single semantic neighborhood.
        all_docs = list(vectorstore.docstore._dict.values())
        step = max(1, len(all_docs) // k)
        docs = all_docs[::step][:k]

    return "\n\n---\n\n".join(d.page_content for d in docs)


def generate_quiz_from_store(
    store_path: str,
    num_questions: int = 5,
    difficulty: str = "medium",
    topic_hint: str = "",
) -> List[Dict[str, Any]]:
    vectorstore = load_vectorstore(store_path)
    context = _gather_context(vectorstore, topic_hint)

    if not context.strip():
        raise ValueError("Could not retrieve any content from the indexed document.")

    llm = _get_llm()
    prompt = _MCQ_PROMPT.format(
        context=context,
        num_questions=num_questions,
        difficulty=difficulty,
        topic_hint=f" focused on: {topic_hint}." if topic_hint else "",
    )

    response = llm.invoke(prompt)
    raw_text = response.content if hasattr(response, "content") else str(response)

    parsed = _extract_json(raw_text)
    questions = parsed.get("questions", [])

    # Basic validation / cleanup
    valid_questions = []
    for q in questions:
        if (
            isinstance(q, dict)
            and "question" in q
            and "options" in q
            and "correct_answer" in q
            and set(q["options"].keys()) >= {"A", "B", "C", "D"}
            and q["correct_answer"] in {"A", "B", "C", "D"}
        ):
            valid_questions.append(q)

    if not valid_questions:
        raise ValueError("Model did not return any valid, well-formed questions.")

    return valid_questions
