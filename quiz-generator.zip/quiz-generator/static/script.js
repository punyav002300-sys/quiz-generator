let sessionId = null;
let currentQuiz = [];

const uploadForm = document.getElementById("upload-form");
const uploadStatus = document.getElementById("upload-status");
const configSection = document.getElementById("config-section");
const generateBtn = document.getElementById("generate-btn");
const generateStatus = document.getElementById("generate-status");
const quizSection = document.getElementById("quiz-section");
const quizContainer = document.getElementById("quiz-container");
const submitQuizBtn = document.getElementById("submit-quiz-btn");
const scoreResult = document.getElementById("score-result");

function setStatus(el, message, type) {
  el.textContent = message;
  el.className = "status" + (type ? " " + type : "");
}

uploadForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const fileInput = document.getElementById("document");
  if (!fileInput.files.length) return;

  const formData = new FormData();
  formData.append("document", fileInput.files[0]);

  setStatus(uploadStatus, "Uploading and indexing document...", "");
  document.getElementById("upload-btn").disabled = true;

  try {
    const res = await fetch("/upload", { method: "POST", body: formData });
    const data = await res.json();

    if (!res.ok) throw new Error(data.error || "Upload failed.");

    sessionId = data.session_id;
    setStatus(
      uploadStatus,
      `Indexed "${data.filename}" into ${data.chunks_indexed} chunks. Ready to generate a quiz.`,
      "success"
    );
    configSection.classList.remove("hidden");
  } catch (err) {
    setStatus(uploadStatus, err.message, "error");
  } finally {
    document.getElementById("upload-btn").disabled = false;
  }
});

generateBtn.addEventListener("click", async () => {
  if (!sessionId) return;

  const num_questions = parseInt(document.getElementById("num_questions").value, 10);
  const difficulty = document.getElementById("difficulty").value;
  const topic_hint = document.getElementById("topic_hint").value.trim();

  setStatus(generateStatus, "Generating quiz with AI... this can take a moment.", "");
  generateBtn.disabled = true;

  try {
    const res = await fetch("/generate_quiz", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ session_id: sessionId, num_questions, difficulty, topic_hint }),
    });
    const data = await res.json();

    if (!res.ok) throw new Error(data.error || "Quiz generation failed.");

    currentQuiz = data.quiz;
    renderQuiz(currentQuiz);
    setStatus(generateStatus, `Generated ${currentQuiz.length} questions.`, "success");
    quizSection.classList.remove("hidden");
    scoreResult.textContent = "";
  } catch (err) {
    setStatus(generateStatus, err.message, "error");
  } finally {
    generateBtn.disabled = false;
  }
});

function renderQuiz(quiz) {
  quizContainer.innerHTML = "";
  quiz.forEach((q, idx) => {
    const block = document.createElement("div");
    block.className = "question-block";

    const title = document.createElement("div");
    title.className = "question-title";
    title.textContent = `${idx + 1}. ${q.question}`;
    block.appendChild(title);

    Object.entries(q.options).forEach(([key, text]) => {
      const label = document.createElement("label");
      label.className = "option-label";
      label.dataset.qIndex = idx;
      label.dataset.optionKey = key;

      const input = document.createElement("input");
      input.type = "radio";
      input.name = `question-${idx}`;
      input.value = key;

      label.appendChild(input);
      label.append(`${key}. ${text}`);
      block.appendChild(label);
    });

    quizContainer.appendChild(block);
  });
}

submitQuizBtn.addEventListener("click", () => {
  let correctCount = 0;

  currentQuiz.forEach((q, idx) => {
    const selected = document.querySelector(`input[name="question-${idx}"]:checked`);
    const labels = document.querySelectorAll(`.option-label[data-q-index="${idx}"]`);

    labels.forEach((label) => {
      const key = label.dataset.optionKey;
      if (key === q.correct_answer) label.classList.add("correct");
      if (selected && key === selected.value && key !== q.correct_answer) {
        label.classList.add("incorrect");
      }
    });

    if (selected && selected.value === q.correct_answer) correctCount += 1;
  });

  scoreResult.textContent = `You scored ${correctCount} / ${currentQuiz.length}`;
});
